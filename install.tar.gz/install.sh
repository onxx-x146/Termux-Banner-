#!/data/data/com.termux/files/usr/bin/bash

# Open GitHub
echo -e "\033[38;5;214m[$current_time]\033[0m \033[1;32m[INFO]:\033[0mInstagram Open..."
am start -a android.intent.action.VIEW -d "https://Instagram.com/_insrnx_" com.android.chrome >/dev/null 2>&1 || {
    echo -e "\033[38;5;214m[$current_time]\033[0m \033[1;33m[WARNING]:\033[0m Could not open ."
}

# ============================================================
#             CUSTOM TERMUX BANNER INSTALLER
#        BASH + FISH + STARSHIP + COLORS + FONT
# ============================================================

set -e

HOME="${HOME:-/data/data/com.termux/files/home}"
CONFIG_DIR="$HOME/.config"
FISH_DIR="$CONFIG_DIR/fish"
THEME_DIR="$HOME/.custom-termux"
BACKUP_DIR="$HOME/.custom-termux-backup-$(date +%Y%m%d-%H%M%S)"

# ============================================================
# COLORS
# ============================================================

RED='\033[1;31m'
GREEN='\033[1;34m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
RESET='\033[0m'

clear

# ============================================================
# HEADER
# ============================================================

printf "${RED}"
printf '╔══════════════════════════════════════════════════════╗\n'
printf '║              CUSTOM TERMUX INSTALLER                ║\n'
printf '╚══════════════════════════════════════════════════════╝\n'
printf "${RESET}\n"

# ============================================================
# ASK SETTINGS
# ============================================================

while true; do
    printf "${CYAN}Enter Banner Name: ${RESET}"
    read -r BANNER_NAME
    [ -n "$BANNER_NAME" ] && break
done

while true; do
    printf "${CYAN}Enter Prompt Name: ${RESET}"
    read -r PROMPT_NAME
    [ -n "$PROMPT_NAME" ] && break
done

printf "${CYAN}Enter Creator Name: ${RESET}"
read -r CREATOR_NAME

if [ -z "$CREATOR_NAME" ]; then
    CREATOR_NAME="$BANNER_NAME"
fi

printf "${CYAN}Enter Telegram Channel URL: ${RESET}"
read -r TELEGRAM_URL

if [ -z "$TELEGRAM_URL" ]; then
    TELEGRAM_URL="https://t.me/YOUR_CHANNEL"
fi

# ============================================================
# DIRECTORIES
# ============================================================

mkdir -p "$CONFIG_DIR"
mkdir -p "$FISH_DIR"
mkdir -p "$THEME_DIR"
mkdir -p "$HOME/.termux"
mkdir -p "$BACKUP_DIR"

# ============================================================
# BACKUP
# ============================================================

printf "\n${YELLOW}[1/8] Creating backup...${RESET}\n"

[ -f "$HOME/.bashrc" ] &&
    cp -f "$HOME/.bashrc" "$BACKUP_DIR/bashrc.bak"

[ -f "$FISH_DIR/config.fish" ] &&
    cp -f "$FISH_DIR/config.fish" "$BACKUP_DIR/config.fish.bak"

[ -f "$CONFIG_DIR/starship.toml" ] &&
    cp -f "$CONFIG_DIR/starship.toml" "$BACKUP_DIR/starship.toml.bak"

[ -f "$HOME/.termux/colors.properties" ] &&
    cp -f "$HOME/.termux/colors.properties" \
          "$BACKUP_DIR/colors.properties.bak"

# ============================================================
# INSTALL PACKAGES
# ============================================================

printf "${YELLOW}[2/8] Installing Fish and Starship...${RESET}\n"

pkg update -y >/dev/null 2>&1 || true
pkg install -y fish starship >/dev/null 2>&1 || true

# ============================================================
# SAVE SETTINGS
# ============================================================

cat > "$THEME_DIR/settings" <<EOF
BANNER_NAME=$(printf '%q' "$BANNER_NAME")
PROMPT_NAME=$(printf '%q' "$PROMPT_NAME")
CREATOR_NAME=$(printf '%q' "$CREATOR_NAME")
TELEGRAM_URL=$(printf '%q' "$TELEGRAM_URL")
PROMPT_SYMBOL='❯'
EOF

# ============================================================
# CREATE BANNER
# EXACT USER-PROVIDED BANNER
# COLOR: RED
# ============================================================

printf "${YELLOW}[3/8] Creating red banner...${RESET}\n"

cat > "$HOME/.custom-termux-banner" <<EOF
#!/data/data/com.termux/files/usr/bin/bash

printf '\033[2J\033[H'
printf '\033[1;31m'

cat <<'ONXXBANNER'
⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀IG _insrnx_⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰
⠈⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠁
⠀⢸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡇⠀
⠀⠀⢳⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⡞⠀⠀
⠀⠀⠘⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⢸⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡇⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠃⠀⠀
⠀⠀⠀⠹⣯⡄⠀⠀⠀⠀⠀⠀⠀⢰⣿⣆      ⠀⠀⣰⣿⡏⠀⠀⠀⠀⠀⠀⠀⢠⣷⠏⠀⠀⠀
⠀⠀⠀⠀⢿⡿⡄⠀⠀⠀⠀⠀⠀⠘⣿⣿⢦⠀⠀⠀⠀⠀⠀⡰⣿⣿⠃⠀⠀⠀⠀⠀⠀⢀⢯⡿⠀⠀⠀⠀
⠀⠀⠀⠀⠘⣿⣿⣦⡀⠀⠀⠀⠀⠀⡾⣿⡎⢣⠀⠀⠀⠀⡴⢡⣿⣷⠀⠀⠀⠀⠀⢀⣴⣿⣿⠃⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢻⣿⣻⣿⣶⣄⠀⠀⠀⢷⣿⣿⡄⠁⠀⠀⠈⢠⣿⣿⡾⠀⠀⠀⣠⣴⣿⣟⣾⡟⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢎⣿⣿⣿⣻⣿⣷⣌⠈⣸⣾⣿⣿⣌⢱⡌⠉⢿⣿⣿⣏⠡⣩⣾⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠢⢔⣺⣿⣿⣿⣿⣿⣾⣽⡦⣿⣿⣿⣷⣿⣿⣾⣿⣿⣿⢙⣮⣿⣿⣿⣿⣿⣿⣇⡧⠔⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠉⠻⣿⣿⣿⣿⣿⣿⣧⢳⣿⣿⡿⣿⣿⢿⣿⣿⡞⣼⣿⣿⣿⣿⣿⣿⡟⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣼⣿⣿⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿ $ ⣿⣿ ⣿⣿ $  ⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀  ⠀BY HARI ⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀IG _insrnx_ 
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢮⡙⢿⠻⣿⣿V⣿⣿⣿⠟⡿⢋⡵⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀ <=============>⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⢿⣧⠻⠿⣿⣿⠿⠟⣼⡿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠣⠀⢹⡏⠀⠴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
ONXXBANNER

printf '\n'
printf '                 %s~❯\n' "$ONXX -X146"
printf '\n'
printf '                 CREATED BY : %s\n' "$BY HARI 🥷🏻"
printf '                 TELEGRAM   : %s\n' "$https://t.me/vasu90"
printf '\n'
printf '\033[0m'
EOF

chmod +x "$HOME/.custom-termux-banner"

# ============================================================
# BASH
# ============================================================

printf "${YELLOW}[4/8] Configuring Bash...${RESET}\n"

cat > "$HOME/.bashrc" <<EOF
# ============================================================
#                 CUSTOM TERMUX BASH
# ============================================================

case \$- in
    *i*) ;;
    *) return ;;
esac

# ------------------------------------------------------------
# Banner on every new interactive Bash session
# ------------------------------------------------------------

if [ -z "\${CUSTOM_TERMUX_BANNER_SHOWN:-}" ]; then
    export CUSTOM_TERMUX_BANNER_SHOWN=1

    if [ -f "\$HOME/.custom-termux-banner" ]; then
        bash "\$HOME/.custom-termux-banner"
    fi
fi

# ------------------------------------------------------------
# Permanent prompt
# Format: NAME~❯
# ------------------------------------------------------------

PS1='\[\033[1;31m\]$PROMPT_NAME~\[\033[1;32m\]❯ \[\033[0m\]'

# ------------------------------------------------------------
# Aliases
# ------------------------------------------------------------

alias ll='ls -lah --color=auto'
alias la='ls -A --color=auto'
alias l='ls -CF'
alias c='clear'

export CUSTOM_TERMUX_THEME="\$HOME/.custom-termux"

# ============================================================
EOF

# ============================================================
# FISH
# ============================================================

printf "${YELLOW}[5/8] Configuring Fish...${RESET}\n"

cat > "$FISH_DIR/config.fish" <<EOF
# ============================================================
#                 CUSTOM TERMUX FISH
# ============================================================

# Banner
if not set -q CUSTOM_TERMUX_BANNER_SHOWN
    set -gx CUSTOM_TERMUX_BANNER_SHOWN 1

    if test -f "\$HOME/.custom-termux-banner"
        bash "\$HOME/.custom-termux-banner"
    end
end

# ------------------------------------------------------------
# Permanent prompt
# Format: NAME~❯
# ------------------------------------------------------------

function fish_prompt
    set_color red
    printf '%s~' '$PROMPT_NAME'

    set_color green
    printf '❯ '

    set_color normal
end

# Aliases
alias ll 'ls -lah'
alias la 'ls -A'
alias l 'ls -CF'
alias c 'clear'

# ============================================================
EOF

# ============================================================
# STARSHIP
# ============================================================

printf "${YELLOW}[6/8] Configuring Starship...${RESET}\n"

cat > "$CONFIG_DIR/starship.toml" <<EOF
# ============================================================
#                 CUSTOM STARSHIP CONFIG
# ============================================================

add_newline = true

format = """
[\$username](bold red)~[\$character](bold green) """

[username]
show_always = true
format = "[$PROMPT_NAME](bold red)"

[character]
success_symbol = "[❯](bold green)"
error_symbol = "[❯](bold red)"
vimcmd_symbol = "[❯](bold green)"

[directory]
style = "bold cyan"
format = "[$path]($style) "

[package]
disabled = true
EOF

# ============================================================
# APPLY UPLOADED THEME FILES
# ============================================================

printf "${YELLOW}[7/8] Applying colors and font...${RESET}\n"

if [ -f "./colors.properties" ]; then
    cp -f "./colors.properties" \
        "$HOME/.termux/colors.properties"
fi

if [ -f "./UbuntuMonoNerdFontPropo-Regular.ttf" ]; then
    cp -f "./UbuntuMonoNerdFontPropo-Regular.ttf" \
        "$HOME/.termux/font.ttf"
fi

if [ -f "./starship.toml" ]; then
    cp -f "./starship.toml" \
        "$THEME_DIR/original-starship.toml"
fi

# ============================================================
# RELOAD
# ============================================================

printf "${YELLOW}[8/8] Applying Termux settings...${RESET}\n"

if command -v termux-reload-settings >/dev/null 2>&1; then
    termux-reload-settings >/dev/null 2>&1 || true
fi

# ============================================================
# DONE
# ============================================================

clear

printf "${GREEN}"
printf '╔══════════════════════════════════════════════════════╗\n'
printf '║                  INSTALLATION DONE                  ║\n'
printf '╚══════════════════════════════════════════════════════╝\n'
printf "${RESET}\n"

printf "${WHITE}Banner : ${CYAN}%s${RESET}\n" "$BANNER_NAME"
printf "${WHITE}Prompt : ${CYAN}%s~❯${RESET}\n" "$PROMPT_NAME"
printf "${WHITE}Creator: ${CYAN}%s${RESET}\n" "$BY Hari 🥷🏻"
printf "${WHITE}Telegram: ${CYAN}%s${RESET}\n" "$https://t me/vasu90"

printf "\n"
printf "${YELLOW}Restart Bash with:${RESET}\n"
printf "exec bash\n\n"

printf "${GREEN}Permanent prompt:${RESET} "
printf "${RED}%s~${GREEN}❯${RESET}\n\n" "$PROMPT_NAME"
