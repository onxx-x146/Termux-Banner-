#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#                    ONXX • TERMUX FISH
# Root package keeps only: install.sh + onxx.sh
# All tool assets live inside: ./Onxx/
# ============================================================
set -e

HOME="${HOME:-/data/data/com.termux/files/home}"
CONFIG_DIR="$HOME/.config"
FISH_DIR="$CONFIG_DIR/fish"
TERMUX_DIR="$HOME/.termux"
THEME_DIR="$HOME/.custom-termux"
ONXX_HOME="$HOME/Onxx"
BACKUP_DIR="$HOME/.custom-termux-backup-$(date +%Y%m%d-%H%M%S)"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ASSET_DIR="$SCRIPT_DIR/Onxx"

RED='\033[1;31m'; GREEN='\033[1;32m'; CYAN='\033[1;36m'; YELLOW='\033[1;33m'; RESET='\033[0m'

printf "${CYAN}ONXX • Termux Fish setup${RESET}\n\n"

[ -d "$ASSET_DIR" ] || { printf "${RED}ERROR: Onxx folder missing.${RESET}\n"; exit 1; }
for f in config.fish fish_variables .custom-termux-banner; do
    [ -f "$ASSET_DIR/$f" ] || { printf "${RED}ERROR: Onxx/$f missing.${RESET}\n"; exit 1; }
done

mkdir -p "$FISH_DIR" "$TERMUX_DIR" "$THEME_DIR" "$BACKUP_DIR" "$ONXX_HOME"

printf "${YELLOW}[1/5] Backing up existing files...${RESET}\n"
for f in \
    "$FISH_DIR/config.fish" \
    "$FISH_DIR/fish_variables" \
    "$HOME/.custom-termux-banner" \
    "$CONFIG_DIR/starship.toml" \
    "$TERMUX_DIR/colors.properties" \
    "$TERMUX_DIR/font.ttf"
do
    if [ -f "$f" ]; then cp -f "$f" "$BACKUP_DIR/$(basename "$f").bak"; fi
done

printf "${YELLOW}[2/5] Installing Fish/Starship...${RESET}\n"
pkg update -y >/dev/null 2>&1 || true
pkg install -y fish starship >/dev/null 2>&1 || true

printf "${YELLOW}[3/5] Installing ONXX files...${RESET}\n"
cp -f "$ASSET_DIR/config.fish" "$FISH_DIR/config.fish"
cp -f "$ASSET_DIR/fish_variables" "$FISH_DIR/fish_variables"
cp -f "$ASSET_DIR/.custom-termux-banner" "$HOME/.custom-termux-banner"

[ -f "$ASSET_DIR/colors.properties" ] && cp -f "$ASSET_DIR/colors.properties" "$TERMUX_DIR/colors.properties"
[ -f "$ASSET_DIR/UbuntuMonoNerdFontPropo-Regular.ttf" ] && cp -f "$ASSET_DIR/UbuntuMonoNerdFontPropo-Regular.ttf" "$TERMUX_DIR/font.ttf"
[ -f "$ASSET_DIR/starship.toml" ] && cp -f "$ASSET_DIR/starship.toml" "$THEME_DIR/original-starship.toml"

# Keep a complete copy of the ONXX tool in ~/Onxx.
# The installer and launcher are intentionally NOT copied there.
cp -Rf "$ASSET_DIR/." "$ONXX_HOME/"
chmod 700 "$ONXX_HOME" 2>/dev/null || true
chmod 600 "$FISH_DIR/config.fish" "$FISH_DIR/fish_variables"
chmod 755 "$HOME/.custom-termux-banner"

fish -c 'set -U fish_greeting ""' >/dev/null 2>&1 || true

printf "${YELLOW}[4/5] Configuring Fish...${RESET}\n"
FISH_BIN="$(command -v fish || true)"
if [ -n "$FISH_BIN" ] && command -v chsh >/dev/null 2>&1; then
    chsh -s "$FISH_BIN" >/dev/null 2>&1 || true
fi

printf "${YELLOW}[5/5] Reloading Termux settings...${RESET}\n"
if command -v termux-reload-settings >/dev/null 2>&1; then
    termux-reload-settings >/dev/null 2>&1 || true
fi

printf "\n${GREEN}========================================${RESET}\n"
printf "${GREEN} ONXX Fish setup completed successfully${RESET}\n"
printf "${GREEN}========================================${RESET}\n"
printf "ONXX files: %s\n" "$ONXX_HOME"
printf "Backup: %s\n" "$BACKUP_DIR"
printf "\n${CYAN}Starting Fish automatically...${RESET}\n\n"

if [ -x "$FISH_BIN" ]; then
    exec "$FISH_BIN"
else
    printf "${YELLOW}Fish was not found. Reopen Termux and run: fish${RESET}\n"
fi
