# ============================================================
#                    VEMON • TERMUX FISH
# ============================================================

# Banner
if not set -q CUSTOM_TERMUX_BANNER_SHOWN
    set -gx CUSTOM_TERMUX_BANNER_SHOWN 1

    if test -f "$HOME/.custom-termux-banner"
        bash "$HOME/.custom-termux-banner"
    end
end

# ------------------------------------------------------------
#                  VEMON PREMIUM PROMPT
# ------------------------------------------------------------

function fish_prompt
    set_color green
    printf '\n╭─[ '

    set_color green
    printf 'VEMON'

    set_color green
    printf ']                                      ➠ '

    set_color green
    printf '%s' (date '+%H:%M:%S')


    set_color white
    printf ']\n╰─➤ '

    set_color normal
end

# ------------------------------------------------------------
#                    ALIASES
# ------------------------------------------------------------

alias ll 'ls -lah'
alias la 'ls -A'
alias l 'ls -CF'
alias c 'clear'

# Quick commands
alias cls 'clear'
alias home 'cd ~'

# ============================================================
