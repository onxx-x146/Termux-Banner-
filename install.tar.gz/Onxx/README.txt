VEMON TERMUX FISH PACKAGE

The supplied files are installed to:
  ~/.config/fish/config.fish
  ~/.config/fish/fish_variables
  ~/.custom-termux-banner

The installer also keeps the original theme/color/font assets.

Install:
  chmod +x install.sh
  ./install.sh

Then restart Termux or run:
  exec fish

A timestamped backup is created before existing files are replaced.
