#!/data/data/com.termux/files/usr/bin/bash
# ONXX launcher/repair script. Package assets are stored in ./Onxx/
set -e

HOME="${HOME:-/data/data/com.termux/files/home}"
FISH_DIR="$HOME/.config/fish"
ASSET_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/Onxx"

[ -d "$ASSET_DIR" ] || { echo "ERROR: Onxx folder missing."; exit 1; }

mkdir -p "$FISH_DIR"
pkg update -y >/dev/null 2>&1 || true
pkg install -y fish >/dev/null 2>&1 || true
fish -c 'set -U fish_greeting ""' >/dev/null 2>&1 || true

cp -f "$ASSET_DIR/config.fish" "$FISH_DIR/config.fish"
cp -f "$ASSET_DIR/fish_variables" "$FISH_DIR/fish_variables"
cp -f "$ASSET_DIR/.custom-termux-banner" "$HOME/.custom-termux-banner"
chmod 600 "$FISH_DIR/config.fish" "$FISH_DIR/fish_variables"
chmod 755 "$HOME/.custom-termux-banner"

if [ -f "$ASSET_DIR/colors.properties" ]; then cp -f "$ASSET_DIR/colors.properties" "$HOME/.termux/colors.properties"; fi
if [ -f "$ASSET_DIR/UbuntuMonoNerdFontPropo-Regular.ttf" ]; then cp -f "$ASSET_DIR/UbuntuMonoNerdFontPropo-Regular.ttf" "$HOME/.termux/font.ttf"; fi
'clear'
printf '\033[1;32m\n'
printf '⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠀⠀⠀⠉⣷⣄⡆⠀⠀\n'⠀⠀⠀⠀⠀⠀⠀⠀
printf '⠀⠀⠀⠀⢠⡀⠀⠀⠀⣠⣴⣿⢀⢄⣠⣴⣿⡇⣿⣆⠀⠀⢀⡄\n'⠀⠀⠀⠀⠀
printf '⠀⠀⠀⠀⢀⣿⠀⢰⣸⣿⣿⣿⣏⣿⣿⣿⣿⣼⣿⣿⠀⡀⣼⡇⠀⠀\n'⠀⠀⠀
printf '⠀⠀⠀⠀⣼⣿⣧⣬⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣤⣧⣿⣿⡄⠀\n'⠀
printf '⠹⣦⡀⠠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⢀⣴⠋\n'
printf '⠀⠹⣿⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣤⣾⣿⠃⠀\n'
printf '⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀\n'
printf '⠀⠀⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀\n'
printf '⠀⠀⠸⠟⣛⣿⣿⣿⣿⡿⠿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣿⣿⣿⡿⢷⠀⠀⠀\n'
printf '⠀⠀⠀⠀⢨⣿⡿⣿⣿⣿⣄⣈⣹⣿⣿⣿⣁⣃⣴⣿⣿⣿⠟⠋⠀⠈⠀⠀⠀\n'
printf '⠀⠀⠀⠀⠈⠿⠤⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⡏⠁⠀⠀⠀⠀⠀\n'
printf '⠀⠀⠀⠀⠀⠀⠀⠿⠌⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠉⠉⠀⠀⠀⠀⠀⠀\n'⠀
printf '⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠉⣿⣿⣿⣿⡏⠛⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀\n'⠀
printf '⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣿⣿⣿⣿⣿⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n'
printf '⠀⠀⠀⠀⠀⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣦⣀⠀⠀⠀⠀⠀\n'
printf '⠀⠀⠀⠀⠀⠛⠹⡿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢻⡿⠛⠙⠃⠀⠀⠀⠀⠀\n'
printf '⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠉⠘⠛⠛⢿⣿⣯⠁⠀⠘⠀⠀⠀⠀⠀⠀⠀⠀⠀\n'
printf '⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n'
printf ' BY : ONXX • MR HAR \n'
printf ' IG : __.l2l__ \n'
printf ' FOLLOW : IN INSTAGRAM @urr_hari__.02 \n'
printf ' TELEGRAM : https://t.me/onxx90 \n'
printf ' WEBSITE  : https://onxx1.vercel.app/ \n'
printf '\n'


if [ -f "./install.sh" ]; then
    bash "./install.sh"
else
    echo "ERROR: install.sh nahi mila."
    exit 1
fi

FISH_BIN="$(command -v fish || true)"
if [ -x "$FISH_BIN" ]; then exec "$FISH_BIN"; fi

echo "ERROR: fish executable nahi mila."
exit 1