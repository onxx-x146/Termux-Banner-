pkg update -y && pkg install fish -y && \
fish -c 'set -U fish_greeting ""' && \
cp "$PREFIX/etc/bash.bashrc" "$PREFIX/etc/bash.bashrc.backup" && \
cat >> "$PREFIX/etc/bash.bashrc" <<'EOF'

# ONXX - Auto Start Fish
if [[ $- == *i* ]] && command -v fish >/dev/null 2>&1 && [[ -z "$FISH_AUTO_STARTED" ]]; then
    export FISH_AUTO_STARTED=1
    exec fish
fi
EOF
"clear"
echo -e "\e[1;32m"
echo "================================"
echo " ONXX Fish Setup Complete"
echo " Fish greeting disabled"
echo "================================"
echo "Restart Termux."
echo -e "\e[0m"
